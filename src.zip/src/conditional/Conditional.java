/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditional;

import java.util.Scanner;

/**
 *
 * @author lindy
 */
public class Conditional {

    public static void main(String[] args) {
        
        int marks;
        String comment;
        Scanner input = new Scanner(System.in);
                
                System.out.print("Enter marks");
                marks = input.nextInt();
                
                if (marks>=80)
                    comment = "great";
                else if (marks>=70)
                    comment = "good";
                else
                    comment = "poor";
                
                System.out.println("marks: " + marks + "=======comments : " +comment);
                
                        
    }
    
}
