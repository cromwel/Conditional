/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditional;

/**
 *
 * @author lindy
 */
public class conditionalSwitch {
        public static void main(String[] args) {
            
            String comment;
            int marks = 0;
            
                    switch(marks){
                    case 80:
            
                        break;
                    case 70:
                        comment = "good";
                        break;
                    case 60:
                        comment = "trial";
                        break;
                    default: 
                        comment = "poor";
                        break;
                
                }
        }
    
}
