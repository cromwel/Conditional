/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditional;

/**
 *
 * @author lindy
 */
public class conditionalItiniary {
     public static void main(String[] args) {
         int marks = 0;
         String comment;
                   
    
         comment = marks>=80 ? "====great" : marks>=70 ? "====good" : "====poor";
                System.out.println(comment);
                

     }
    
}
